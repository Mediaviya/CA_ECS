#!/bin/bash


usage()
{
    echo "Usage: $0 [install/uninstall] [-p port Number]"
	echo "Exiting"
    exit 1
}

optRequired()
{
    VARNAME="$1"
    VALUE="$2"
    if [ -z "$VALUE" ]
    then
        echo "Argument '$VARNAME' missing value"
        usage
    fi
    eval $VARNAME=\"$VALUE\"
    eval val=\"\$$VARNAME\"
}

fixupWithParser()
{
    KEYWORD="$1"
    SETTING="$2"

    echo "fixupWithParser fn: '$FIXUP_FN','$FIXUP_CMD' kw: '$KEYWORD', setting: '$SETTING'" >> install.log
    if [ -z "$SETTING" ]
    then
        return 1
    fi
    if [ "x$KEYWORD" != "xro" -a "x$KEYWORD" != "xrw" -a "x$KEYWORD" != "xtrap" ]
    then
        eval $FIXUP_CMD -c ADD -t -i "$FIXUP_FN" -o "$FIXUP_FN" -O "$KEYWORD" -N '"$KEYWORD $SETTING"'
    else
	 if [ "x$KEYWORD" = "xro" ]
         then
             ct="read-only"
         else
             ct="read-write"
         fi
	 eval $FIXUP_CMD -c ADD -t -i "$FIXUP_FN" -o "$FIXUP_FN" -O "community" -N '"community $SETTING $ct"'
    fi

    return 1
}

fixupStaticSysedgeCf()
{
    echo "Executing fixupStaticSysedgeCf()">> install.log
    SYSEDGE_CF_NAME=$SYSEDGE_INSTALL_DIR/config/sysedge.cf
    # We use the parser program from PIF_PREINSTALL_DIR to be able to use
    # it early during install process.i
    PARSER_FN="$SYSEDGE_INSTALL_DIR/bin/parser"

    echo "PARSER_FN: $PARSER_FN">> install.log
    FIXUP_CMD="$PARSER_FN"
    FIXUP_FN="$SYSEDGE_CF_NAME"
	SYSEDGE_INSTALL_DIR_1="$echo"${SYSEDGE_INSTALL_DIR//\\/}""
    if fixupWithParser "data_directory" "'$SYSEDGE_INSTALL_DIR_1/config/'"
    then
        #log Update of configuration file "$ARG1" failed.
        echo ERROR: Data directory update failed
        return 22 # EINVAL.
    fi
    if fixupWithParser "default_port" "$SYSEDGE_PORT"
    then
        #log Update of configuration file "$ARG1" failed.
        echo ERROR: Port update failed
        return 22 # EINVAL.
    fi

    #Add Native settings
    if fixupWithParser "sysdescr" "$SNMP_SYS_DESC"
    then
        #log Update of configuration file "$ARG1" failed.
        echo "ERROR: sysdescr update failed"
        return 22 # EINVAL.
    fi

    if fixupWithParser "syscontact" "$SNMP_SYS_CONTACT"
    then
        #log Update of configuration file "$ARG1" failed.
        echo "ERROR: syscontact update failed"
        return 22 # EINVAL.
    fi

    if fixupWithParser "syslocation" "$SNMP_SYS_LOC"
    then
        #log Update of configuration file "$ARG1" failed.
        echo "ERROR: syslocation update failed"
        return 22 # EINVAL.
    fi

    if fixupWithParser "ro" "$rocomm"
    then
        #log Update of configuration file "$ARG1" failed.
        echo "ERROR: rocomm update failed"
        return 22 # EINVAL.
    fi

    if fixupWithParser "rw" "$rwcomm"
    then
        #log Update of configuration file "$ARG1" failed.
        echo "ERROR: rwcomm update failed"
        return 22 # EINVAL.
    fi
}

#
# Name
#   isPortUsed
#
# Description
#   Checks whether a given port is currently used (with netstat). Expects
#   getOsVars was previously called and thus PLAT_NAME and friends are set.
#
# Arguments
#   Value to analyze.
#
# Returns
#   1 when the port is used, 0 if not, -1 if error

isPortUsed()
{
    port=$1
    proto=$2
    if [ -z "$proto" ]
    then
        proto=tcp
    fi
    case "$proto" in
    tcp|udp)
        ;;
    *)
        echo "port must be tcp or udp"
        return -1
        ;;
    esac
    case "$PLAT_NAME" in
    LINUX)
        # A 'netstat -an' line (filtered) looks like the following:
        # tcp        0      0 0.0.0.0:667    0.0.0.0:*  LISTEN
        # udp        0      0 0.0.0.0:661    0.0.0.0:*                         
        # tcp        0      0 ::1:6012       :::*       LISTEN
        # udp        0      0 :::32774       :::*
        OUTPURSTR=`netstat -an | grep -E "^$proto[ 	]+[0-9]+[ 	]+[0-9]+[ 	]+[0-9a-f\.:\*]+:$port[ 	]+"` 
        # TBD OUTPURSTR=`netstat -an "2>/dev/null" \| grep -E "^$proto[ 	]+[0-9]+[ 	]+[0-9]+[ 	]+[0-9a-f\.:\*]+:$port[ 	]+"` 
        CMDSTATUS=$?  
        ;;
    *)
        # unsupported OS
        return -1
        ;;
    esac
    if [ "$CMDSTATUS" -eq 0 -a -n "$OUTPUTSTR" ]
    then
        echo "port $port/$proto is already used"
		echo "Exiting"
		exit
    fi
    echo "port $port/$proto is NOT used">> install.log
    return 0
}

#
# Name
#   isPortReserved
#
# Description
#   Checks whether a port is reserved (in /etc/services).
#
# Arguments
#   Value to analyze.
#
# Returns
#   1 when the port is reserved, 0 if not

isPortReserved()
{
    port=$1
    proto=$2
    if [ -z "$proto" ]
    then
        proto=tcp
    fi
    echo "isPortReserved: port: '$port', proto: '$proto'">> install.log
    OUTPUTSTR=`grep "[ 	]$port/$proto" "/etc/services"`
    CMSTATUS=$?
    if [ "$CMDSTATUS" -eq 0 ]
    then
        ret=1
    else
        ret=0
	echo Port not free
        #exit
    fi
    echo "isPortReserved: $ret" >> install.log
    return $ret
}

# Name
#   disableNativeAgent
#
# Description
#   Stops and disables other snmp agent.
#
# Arguments
#   None.
#
# Environment variables.
#
# Returns
#   0 if ok, non-0 otherwise.
#
disableNativeAgent()
{
    echo "Executing disableNativeAgent"
    case "$PLAT_NAME" in
    LINUX)
        echo "PLAT_LINUX_VENDOR: '$PLAT_LINUX_VENDOR'"
        case "x$PLAT_LINUX_VENDOR" in
        "xREDHAT")
            # Use chkconfig to deregister native agent
            OUTPUTSTR=`/etc/init.d/snmpd status`
            CMDSTATUS=$?
            if [ "$CMDSTATUS" -eq 0 ]
            then
                # log "Stopping native SNMP agent."
                echo $CORE_PACKAGE_NAME
                OUTPUTSTR=`/etc/init.d/snmpd stop`
                CMDSTATUS=$?
                if [ "$CMDSTATUS" -ne 0 ]
                then
                    echo "snmpd stop failed"
                fi
            fi
            OUTPUTSTR=`/sbin/chkconfig --list snmpd | grep :on`
            CMDSTATUS=$?
            if [ "$CMDSTATUS" -ne 0 ]
            then
                # Not enabled - probably not configured with meaningful values.
                return 0
            fi
            # log "Disabling native SNMP agent."
            echo $CORE_PACKAGE_NAME
            OUTPUTSTR=`/sbin/chkconfig --del snmpd`
            CMDSTATUS=$?
            if [ "$CMDSTATUS" -ne 0 ]
            then
                echo "chkconfig --del failed"
            fi
            ;;
        "*")
            # We don't support other Linux distributions
	    echo "ERROR: We don't support other Linux distributions"
		echo "Exiting"
            exit
            ;;
        esac
        return 0
        ;;
    *)
        echo "incorrect PLAT_NAME: '$PLAT_NAME'"
        return 1
        ;;
    esac
    return 1
}

getOsVars()
{
    echo "Executing getOsVars()">> install.log

    OUTPUTSTR=`sh -c uname -s`
    CMDSTATUS=$?
    if [ "$CMDSTATUS" -ne 0 ]
    then
        # Can't really happen
        echo ERROR: uname command not working
	echo "Exiting"
	exit
    fi
    UNAME_S="$OUTPUTSTR"
    _OSVARS_CALLED=1
    case "$UNAME_S" in
    "Linux")
        PLAT_NAME=LINUX
        # Get the machine architecture
        OUTPUTSTR=`uname -m`
        UNAME_M="$OUTPUTSTR"
        if [ "$UNAME_M" = ppc64le ]
        then
            PLAT_ARCH=PPC64LE
            PLAT_BITS=64
            # XXX Should we verify X86 stuff will run?
            PLAT_COMPAT=X86
        elif [ "$UNAME_M" = x86_64 ]
        then
            PLAT_ARCH=x86_64
            PLAT_BITS=64
            # XXX Should we verify X86 stuff will run?
            PLAT_COMPAT=X86
        else
            # On x86 uname -m returns i386/486...
            echo ERROR: Non LINUX platform
        fi
#        OUTPUTSTR=`uname -r`
#        CMDSTATUS=$?
        # Returns something like 2.6.18-53.el5
#        if [ "$CMDSTATUS" -eq 0 -a -n "$OUTPUTSTR" ]
#        then
#            UNAME_R="$OUTPUTSTR"
            #NthArg "$UNAME_R" 1 .;PLAT_LINUX_KERN_MAJOR="$NTHARG_RESULT"
            #NthArg "$UNAME_R" 2 .;PLAT_LINUX_KERN_MINOR="$NTHARG_RESULT"
            #NthArg "$UNAME_R" 3 .;tmp="$NTHARG_RESULT"
            #NthArg "$tmp" 1 -;PLAT_LINUX_KERN_SUBMINOR="$NTHARG_RESULT"
#            echo "Linux kernel version: $PLAT_LINUX_KERN_MAJOR.$PLAT_LINUX_KERN_MINOR.$PLAT_LINUX_KERN_SUBMINOR"
#        fi
#        if [ -f /etc/redhat-release ]
#        then
#            PLAT_LINUX_VENDOR=REDHAT
#            PLAT_RUNLEVEL_ROOTDIR="/etc"
            # We are Red Hat
            # /etc/redhat-release contains e.g.:
            ###
            # Red Hat Enterprise Linux Server release 5.1 (Tikanga)
            # or
            # Red Hat Enterprise Linux ES release 5 (YoungPretender)
            # or
            # Red Hat Enterprise Linux AS release 4 (Nahant Update 4)
            ###
#            if cat /etc/redhat-release | egrep 'release [[:digit:]]\.[[:digit:]]+' > /dev/null
#            then
                # String in the form '...release x.y...' - return x.y
#                PLAT_VER_MAJOR="`cat /etc/redhat-release | sed -e 's/.*release //' -e 's/\..*//'`"
#                PLAT_VER_MINOR="`cat /etc/redhat-release | sed -e 's/.*release //' -e 's/.*\.//' -e 's/[^0-9].*//'`"
#            elif cat /etc/redhat-release | egrep 'release [[:digit:]] \(.* Update [[:digit:]]' > /dev/null
#            then
                # String in the form '...release x (... Update y...' - return x.y
#                PLAT_VER_MAJOR="`cat /etc/redhat-release | sed -e 's/.*release //' -e 's/[     ].*//'`"
#                PLAT_VER_MINOR="`cat /etc/redhat-release | sed -e 's/.*Update //' -e 's/[^0-9].*//'`"
#            elif cat /etc/redhat-release | egrep 'release [[:digit:]]' > /dev/null
#            then
                # String in the form '...release x...' - return x.0
#                PLAT_VER_MAJOR="`cat /etc/redhat-release | sed -e 's/.*release //' -e 's/[     ].*//'`"
#            elif cat /etc/redhat-release | grep Tikanga > /dev/null
#            then
                # Tikanga is code name for Major 5
#                PLAT_VER_MAJOR=5
#            elif cat /etc/redhat-release | grep Nahant > /dev/null
#            then
                # Nahant is code name for Major 4
#                PLAT_VER_MAJOR=4
#            else
#                PLAT_VER_MAJOR=-1
#            fi
#	fi
#        if [ -z "$PLAT_LINUX_VENDOR" ]
#        then
#            PLAT_LINUX_VENDOR=UNKNOWN
#            echo "Unsupported Linux"
#            return 1
#        fi
        ;;
    *)
        echo "We don't support other Linux distributions"
		echo "Exiting"
        exit
        ;;
    esac
#    if [ -z "$INSTALL_PLAT_NAME" ]
#    then
#       PLAT_NAME+="$INSTALL_PLAT_NAME"
#    fi
#    if [ -z "$INSTALL_PLAT_ARCH" ]
#    then
#       PLAT_ARCH+="INSTALL_PLAT_ARCH"
#    else
#       # We could be making sure INSTALL_PLAT_* is set sensibly here.
#        platOverRide "$INSTALL_PLAT_NAME" "$INSTALL_PLAT_ARCH"
#        if [ "$?" -eq 0 ]
#        then
#            echo "PlatOverRide failed"
#            return 1
#        fi
#    fi
#    if [ -z "$PLAT_VER_MINOR" ]
#    then
#        PLAT_VER_MINOR=0
#    fi
#    echo "getOsVars: pn: $PLAT_NAME, ver: $PLAT_VER_MAJOR.$PLAT_VER_MINOR, arch: $PLAT_ARCH/$INSTALL_PLAT_ARCH, compat: '$PLAT_COMPAT'">> install.log
    return 0
}


#
# Name
#   readOneKeyword
#
# Description
#   Finds a keyword in a text config file and return either the word
#   right after it or the rest of line.
#
# Arguments
#   $1      filename to search in
#   $2      keyword (e.g. sysdescr)
#   $3      (optional) argument to 2nd NthArg - default 2- to return
#           rest of line, can be e.g. 2 to only return 2nd word
#   $4      (optional) separator of key and value - default is unspecified
#           (e.g. whitespace) - can be e.g. `=' - key=value
#           rest of line, can be e.g. 2 to only return 2nd word
#
# Environment variables.
#   KW_CASE_SENSITIVE       IN      Case sensitiveness of the search
#   ONE_KEYWORD             OUT     Result - the value of the keyword.
#
readOneKeyword()
{
    sefn="$1"
    keyword="$2"
    
    echo "Executing readOneKeyword, sefn: '$sefn', keyword: '$keyword'">> install.log
    if [ ! -r "$sefn" ] 
    then
        return
    fi

    OUTPUTSTR=`grep "^[ 	]*$keyword" "$sefn" | head -1 | cut -d' ' -f2`
    CMDSTATUS=$?
    echo OUTPUTSTR $OUTPUTSTR>> install.log
    ONE_KEYWORD=
    if [ "$CMDSTATUS" -eq 0 -a -n "$OUTPUTSTR" ]
    then
        # TBD Take out value and fill in value parameter
        ONE_KEYWORD="$OUTPUTSTR"
    	echo "readOneKeyword result: (keyword '$keyword') '$ONE_KEYWORD'">> install.log
	return 0
    fi
    echo "readOneKeyword result: (keyword '$keyword') '$ONE_KEYWORD'">> install.log
    return 1
}

#
# Name
#   readAllKeywords
#
# Description
#   Finds all lines with keyword in a text config file and return either
#   the list of the values separated by `;' or $4.
#
# Arguments
#   $1      filename to search in
#   $2      keyword (e.g. sysdescr)
#   $3      (optional) argument to 2nd NthArg - default 2- to return
#           rest of line, can be e.g. 2 to only return 2nd word
#   $4      (optional) separator of output values (default `;')
#
# Environment variables.
#   KW_CASE_SENSITIVE       IN      Case sensitiveness of the search
#   ALL_KEYWORDS            OUT     Result - the values of the keyword.
#
readAllKeywords()
{
    sefn="$1"
    keyword="$2"
    echo "Executing readAllKeywords, sefn: '$sefn', keyword: '$keyword'">> install.log
    if [ ! -r "$sefn" ] 
    then
        return
    fi

    ALL_KEYWORDS=
    OUTPUTSTR=`grep "^[ 	]*$keyword" "$sefn" | cut -d' ' -f2`
    CMDSTATUS=$?
    if [ "$CMDSTATUS" -eq 0 -a -n "$OUTPUTSTR" ]
    then
        for aline in $OUTPUTSTR
        do
            if [ -n "$result" ]
            then
                result="${result};${aline}"
            else
                result="$aline"
            fi
        done
        ALL_KEYWORDS="$result"
    	echo "readAllKeywords result: (keyword '$keyword') '$ALL_KEYWORDS'">> install.log
	return 0
    fi
    echo "readAllKeywords result: (keyword '$keyword') '$ALL_KEYWORDS'"
    return 0
}

# Name
#   readNetSNMPSettings
#
# Description
#   Read Net-SNMP snmpd.conf config file and sets SE configuration variables
#   accordingly.
#
# Arguments
#   $1  configuration file
#
# Environment variables.
#
# Returns
#
readNetSNMPSettings()
{
    SNMPD_CONF="$1"
    echo "readNetSNMPSettings fn: '$SNMPD_CONF'"
    if [ ! -r "$SNMPD_CONF" ]
    then
        echo "Can't open config file '$SNMPD_CONF'"
        # Not enabled - probably not configured with meaningful values.
        return
    fi
    if [ "x$PLAT_NAME" = "xLINUX" ]
    then
        case "x$PLAT_LINUX_VENDOR" in
        "xREDHAT")
            OUTPURSTR=`/sbin/chkconfig --list snmpd | grep :on`
            CMDSTATUS=$?
	    if [ "$CMDSTATUS" -eq 0 ]
            then
                echo "Snmpd not enabled, not inheriting config"
                # Not enabled - probably not configured with meaningful values.
                return
            fi
            ;;
        "*")
            echo "Unsupported Linux distribution. Not inheriting config."
            return
            ;;
        esac
    fi

    readOneKeyword "$SNMPD_CONF" syslocation
    if [ $? -eq 0 ]
    then
        SNMP_SYS_LOC="$ONE_KEYWORD"
        # TBD Add to config
        #defaultSettingFromNative SNMP_SYS_LOC "$tmp"
    fi

    readOneKeyword "$SNMPD_CONF" syscontact
    if [ $? -eq 0 ]
    then
        SNMP_SYS_CONTACT="$ONE_KEYWORD"
        # TBD Add to config
        #defaultSettingFromNative SNMP_SYS_CONTACT "$tmp"
    fi

    readOneKeyword "$SNMPD_CONF" sysdescr;
    if [ $? -eq 0 ]
    then
        SNMP_SYS_DESC="$ONE_KEYWORD"
        # TBD Add to config
        #defaultSettingFromNative SNMP_SYS_DESC "$tmp"
    fi
    # Read all lines containing rocommunity community-name ...
    # and store the list of community names separated by ;
    # If a line contains more than a community name we ignore it
    # because it can contain things SE does not support. Ignoring
    # the complex settings and just using the community
    # might be considered security issue - e.g. it can specify a IP
    # network to allow access only to a part of MIB and we would
    # allow access by anybody to everything.

    readOneKeyword $SNMPD_CONF rocommunity;
    rocomm="$ONE_KEYWORD"

    #readAllKeywords $SNMPD_CONF rocommunity;
    #rocomm="$ALL_KEYWORDS"
    # We don't make a differenece in IPv4 and IPv6 communities
    #readAllKeywords $SNMPD_CONF rocommunity6;
    #tmp="$ALL_KEYWORDS"

    #if [ -n "$tmp" ]
    #then
     #   if [ -n "$rocomm" ]
      #  then
       #     rocomm="$rocomm;$tmp"
    #    else
     #       rocomm="$tmp"
      #  fi
  #  fi

    readOneKeyword $SNMPD_CONF rwcommunity;
    rwcomm="$ONE_KEYWORD"

#    readAllKeywords $SNMPD_CONF rwcommunity
 #   rwcomm="$ALL_KEYWORDS"
  #  readAllKeywords $SNMPD_CONF rwcommunity6
   # tmp="$ALL_KEYWORDS"

#    if [ -n "$tmp" ]
#    then
 #       if [ -n "$rwcomm" ]
  #      then
   #         rwcomm="$rwcomm;$tmp"
    #    else
     #       rwcomm="$tmp"
      #  fi
#    fi

    # Read _default_ trap community.
 #   readOneKeyword "$SNMPD_CONF" trapcommunity
  #  tmp="$ONE_KEYWORD"
   # deftrapcomm="$tmp"
#    if [ -z "$deftrapcomm" ]
#    then
 #       deftrapcomm=public
  #  fi

    # TBD Add default trap community

    # Read all trap destinations.
    # Format is 'trapsink HOST [COMMUNITY [PORT]]'
    # whereas SE format is 'trap_community COMMUNITY HOST [PORT [FORMAT]]'
   # readAllKeywords $SNMPD_CONF trapsink
   # trapcomm="$ALL_KEYWORDS"
}

readNativeSNMPSettings()
{
    echo "Executing eadNativeSNMPSettings"
    case "$PLAT_NAME" in
    LINUX)
        # Net-SNMP has default config file /etc/snmp/snmpd.conf.
        # Of course it can be reconfigured but we don't try to replicate
        # all the complex Linux startup scripts to adapt.
        # Check snmpd is enabled in current run-level.
        if [ "x$PLAT_LINUX_VENDOR" != "xREDHAT" ]
        then
            # We only support REDHAT. Others probably also use
            # Net-SNMP so should be easy to adapt.
            return
        fi
        # Listening port is specified with recent NetSNMP snmpd on
        # command line and as there are many options the syntax
        # can be rather complicated. The way one can change the
        # port is different on RedHat and SuSe too.

        readNetSNMPSettings "/etc/snmp/snmpd.conf"

        # Port to listen on can be specified on snmpd command line
        # but we don't try to read it.
        ;;
    *)
        echo "incorrect PLAT_NAME: '$PLAT_NAME'"
        ;;
    esac
}

#
# Name
#   startSEAgent
#
# Description
#   Starts SE
#
# Arguments
#   None.
#
# Returns
#   0 if there was no problem, 1 otherwise
#

startSEAgent()
{
    STARTIT=0
    echo "startSEAgent">> install.log
    if eval [ -x "$SYSEDGE_INSTALL_DIR/bin/sysedgectl" ]
    then
        SECTL_BIN="$SYSEDGE_INSTALL_DIR/bin/sysedgectl"
    else
        echo ERROR: sysedgectl not found.
		echo "Exiting"
        exit
    fi
    echo "SECTL_BIN: '$SECTL_BIN'">> install.log
    OUTPURSTR=`eval "$SECTL_BIN" status | grep 'not '`
    CMDSTATUS=$?
    if [ "$CMDSTATUS" -eq 0 ]
    then
        # Only start SE if not already running.
        # Log "Starting CA SystemEDGE service."
        echo "Starting CA SystemEDGE service."
        OUTPURSTR=`eval "$SECTL_BIN" start`
        CMDSTATUS=$?
        if [ "$CMDSTATUS" -ne 0 ]
        then
            # Log "Cannot start $PRODNAME service."
            echo "Cannot start $PRODNAME service."
			echo "Exiting"
            exit
        fi
    fi
    return 0
}

fixupStartupScript()
{
    echo "Executing fixupStartupScript()">> install.log

    STARTUP_FILE="$SYSEDGE_INSTALL_DIR/bin/$1"
    #
    # Customize the startup file
    #
    # Set the directory
	SYSEDGE_INSTALL_DIR_1="$SYSEDGE_INSTALL_DIR"
    eval sed -ie 's!%%CASE_G_INSTALLDIR%%!\"'"${SYSEDGE_INSTALL_DIR}"'\"!g' $SYSEDGE_INSTALL_DIR/bin/CA-SystemEDGE
    if [ "$?" -ne 0 ]
    then
        echo Update of startup script "CASE_G_INSTALLDIR" failed
        return 1
    fi

    eval sed -i 's!%%CASE_G_PUBDATADIR%%!\"'"${SYSEDGE_INSTALL_DIR}"/config'\"!g' $SYSEDGE_INSTALL_DIR/bin/CA-SystemEDGE
    if [ "$?" -ne 0 ]
    then
        echo Update of startup script "CASE_G_PUBDATADIR" failed
        return 1
    fi

    eval sed -i 's!%%CASE_SNMP_PORT%%!'"${SYSEDGE_PORT}"'!g' $SYSEDGE_INSTALL_DIR/bin/CA-SystemEDGE
     if [ "$?" -ne 0 ]
    then
        echo Update of startup script "CASE_SNMP_PORT" failed
        return 1
    fi
     
    # fixing profile.CA
    eval sed -i 's!%%CASE_G_INSTALLDIR%%!\"'"${SYSEDGE_INSTALL_DIR}"'\"!g' $SYSEDGE_INSTALL_DIR/bin/profile.CA
     if [ "$?" -ne 0 ]
    then
        echo Update of startup script "CASE_G_INSTALLDIR" failed
        return 1
    fi

    return 0
}

chkInstallDir()
{
    OUTPUTSTR=`ls $SYSEDGE_INSTALL_DIR/SystemEDGE 2>>install.log`
    CMDSTATUS=$?
    if [ "$CMDSTATUS" -ne 0 ]
    then
        echo Install directory does not exist>>install.log
    else
        echo "Install directory "$SYSEDGE_INSTALL_DIR"/SystemEDGE already exist "
		echo "Exiting"
		exit
    fi
}

###########################################################
# Script execution starts here

#CMDSTATUS=0
#SYSEDGE_PORT=1691
#SYSEDGE_INSTALL_DIR="$HOME"
#rm -rf install.log
#echo Installing SysetemEdge starts > install.log
CMDSTATUS=0
# Read cmd line arguments
if [ "$#" -eq 0 ]
then
	usage
	exit
fi
if [ $1 != "install" ] && [ $1 != "uninstall" ]
then
	usage
	exit
fi

while [ "$#" -gt 0 ]
do
    case "$1" in
    "-p")
        shift
        optRequired SYSEDGE_PORT "$1"
        ;;
    "install")
		SYSEDGE_PORT=1691
		SYSEDGE_INSTALL_DIR="$AGENTHOME"
		rm -rf install.log
		echo Installing SysetemEdge starts > install.log
        ;;
    "uninstall")
		SYSEDGE_PARENT_DIR="$OUTPUTSTR"
		SYSEDGE_INSTALL_DIR="$AGENTHOME"/SystemEDGE
		eval $SYSEDGE_INSTALL_DIR/bin/sysedgectl stop
		eval rm -rf $SYSEDGE_INSTALL_DIR
		echo "uninstall completed" 
		exit
        ;;
    "-h"|"-?"|"--help"|"")
        usage
        ;;
    *)
        # Leave remaining arguments for make_pkgs.sh
        break
        ;;
    esac
    shift
done

echo SYSEDGE_INSTALL_DIR $SYSEDGE_INSTALL_DIR>>install.log
echo SYSEDGE_PORT $SYSEDGE_PORT>>install.log

# checkAllCmds TBD

# get Os Vars (Not tested)
getOsVars

#readNativeSNMPSettings

# verifySNMPSettings TBD

# Check input SNMP port numeric or not TBD
OUTPUTSTR=`expr "$SYSEDGE_PORT" + 0 2>> install.log`
CMDSTATUS=$?
if [ "$CMDSTATUS" -ne 0 ]
 then
     # SNMP PORT is not numeric
    echo ERROR: PORT is not numeric "$SYSEDGE_PORT" 
	echo "Exiting"
    exit
fi
# Check community string TBD 

# disable Native Agent (Not tested)

#disableNativeAgent

# Check port reserved or not (Not tested)
#isPortReserved $SYSEDGE_PORT udp

# Check port in use or not (Not tested)
isPortUsed $SYSEDGE_PORT udp

# check install Dir
chkInstallDir

# untar Sysedge binaries
eval tar -xvf SystemEDGE.pkg -C $SYSEDGE_INSTALL_DIR 1>> install.log
SYSEDGE_INSTALL_DIR=$SYSEDGE_INSTALL_DIR/SystemEDGE


# Fix port folder config file
fixupStaticSysedgeCf

# fixupstartup script 
fixupStartupScript CA-SystemEDGE

#cp $SYSEDGE_INSTALL_DIR/bin/CA-SystemEDGE /etc/init.d/
#cp $SYSEDGE_INSTALL_DIR/bin/profile.CA /etc/

#ln -s /etc/init.d/CA-SystemEDGE "$SYSEDGE_INSTALL_DIR"/bin/sysedgectl
rm -rf "$SYSEDGE_INSTALL_DIR"/bin/sysedgectl
eval ln -s $SYSEDGE_INSTALL_DIR/bin/CA-SystemEDGE "$SYSEDGE_INSTALL_DIR"/bin/sysedgectl

# Start Sysedge
startSEAgent
